package com.cs2340aG49.greenPlate.ui.view;

public interface DatabaseObserver {
    public void update();
}
