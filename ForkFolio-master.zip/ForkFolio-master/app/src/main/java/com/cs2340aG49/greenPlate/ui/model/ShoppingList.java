package com.cs2340aG49.greenPlate.ui.model;
public class ShoppingList extends Pantry {
    public ShoppingList(String user) {
        super(user);
    }

}
