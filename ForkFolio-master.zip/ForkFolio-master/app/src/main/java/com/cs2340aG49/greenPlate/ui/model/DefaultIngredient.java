package com.cs2340aG49.greenPlate.ui.model;

public class DefaultIngredient extends AbstractIngredient {
    public DefaultIngredient(String ingredientName, int ingredientCount) {
        super(ingredientName, ingredientCount);
    }

    public DefaultIngredient(String ingredientName, int ingredientCount, int ingredientCalories) {
        super(ingredientName, ingredientCount, ingredientCalories);
    }
}
