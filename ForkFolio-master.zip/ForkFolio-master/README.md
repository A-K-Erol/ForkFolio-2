# ForkFolio

Android application developed in Android Studio in Java with Firebase. Tracks meals and ingredients, and enables users to share recipes, propose suggestions, and filter/search by their needs.

Contributors: Ansel Erol, Mika Okamoto, Nathan Duggal, Abhinn Vegesna, Tong Jing
